# coding: utf-8
from tira.rest_api_client import Client
from wows_eval import evaluate as wows_evaluate
from autoqrels.zeroshot import GradedMonoPrompt
import pandas as pd

# For measuring consumed resources (e.g., GPU, CPU, RAM, etc.)
from tirex_tracker import tracking, ExportFormat

pd.set_option('display.max_colwidth', None)

DATASET_ID = 'wows-eval/pointwise-smoke-test-20250128-training'

tira = Client()
input_data = tira.pd.inputs(DATASET_ID)
from tira.rest_api_client import Client
from wows_eval import evaluate as wows_evaluate
from autoqrels.zeroshot import GradedMonoPrompt
import pandas as pd

# For measuring consumed resources (e.g., GPU, CPU, RAM, etc.)
from tirex_tracker import tracking, ExportFormat

pd.set_option('display.max_colwidth', None)

DATASET_ID = 'wows-eval/pointwise-smoke-test-20250128-training'

tira = Client()
input_data = tira.pd.inputs(DATASET_ID)
input_data.head(2)
BACKBONE_MODEL = "flan-t5-small"

PROMPT = """Instruction: Indicate if the passage answers the question.
###
Example 1:
Question: At about what age do adults normally begin to lose bone mass?
Passage: For most people, bone mass peaks during the third decade of life. By this age, men typically have accumulated more bone mass than women. After this point, the amount of bone in the skeleton typically begins to decline slowly as removal of old bone exceeds formation of new bone.
Answer: Perfectly relevant
###
Example 2:
Question: when and where did the battle of manassas take place
Passage: Summary of the Battle of Bull Run. The conflict took place close to Manassas Junction, Virginia. Around 35,000 Union soldiers marched from Washing D.C. towards Bull Run (a small river) where a 20,000 troop Confederate force was stationed.
Answer: Irrelevant
###
Example 3:
Question: which kind of continental boundary is formed where two plates move horizontally past one another?
Passage: One plate slides horizontally past another. The best-known example is the earthquake-prone San Andreas Fault Zone of California, which marks the boundary between the Pacific and North America Plates. See: Teaching About Transform Plate Boundaries.
Answer: Highly relevant
###
Example 4:
Question: what foods should you stay away from if you have asthma
Passage: Get early and regular prenatal care. The first 8 weeks of your pregnancy are important to your baby's development. Early and regular prenatal care can boost your chances of having a safe pregnancy and a healthy baby. Prenatal care includes screenings, regular exams, pregnancy and childbirth education, and counseling and support.
Answer: Irrelevant
###
Example 5:
Question: what is lbm in body composition
Passage: They also measured the participantsâ€™ body fat and â€œlean body massâ€ â€“ a measure. Trusted Source. of muscle mass, obtained by subtracting the body fat weight from the total body weight.
Answer: Relevant
###
Example 6:
Question: {{ query_text }}
Passage: {{ unk_doc_text }}
Answer:"""
autoqrels_assessor = GradedMonoPrompt(
    backbone=f'google/{BACKBONE_MODEL}',
    prompt=PROMPT,
    dataset=None
)
get_ipython().system('rm -Rf ir-metadata.yml .tirex-tracker/')

with tracking(export_file_path='ir-metadata.yml', export_format=ExportFormat.IR_METADATA) as tracked_experiment:
    predictions = autoqrels_assessor.predict(input_data)
