#!/usr/bin/env bash

echo '{"id": "foo-1", "text": "a"}' > ${TIRA_OUTPUT_DIR}/preds.jsonl
echo '{"id": "foo-2", "text": "a"}' >> ${TIRA_OUTPUT_DIR}/preds.jsonl
echo '{"id": "foo-3", "text": "a"}' >> ${TIRA_OUTPUT_DIR}/preds.jsonl
echo '{"id": "foo-4", "text": "a"}' >> ${TIRA_OUTPUT_DIR}/preds.jsonl

