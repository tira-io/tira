#!/usr/bin/env bash

echo "hello world" > ${TIRA_OUTPUT_DIR}/preds.txt

